# Task-6 Prediction using Decision Tree Algorithm
Create the Decision Tree classifier and visualize it graphically.
